

<html>
    <head>

    </head>
    <body>
<div class="example">


  <div style="background: linear-gradient(to right, #ee9ca7, #ffdde1)" class="gradient active"></div>

  <div style="background: linear-gradient(to right, #c6ffdd, #fbd786, #f7797d)" class="gradient"></div>

  <div style="background: linear-gradient(to right, #ee9ca7, #8a8a8a)" class="gradient"></div>

  <div style="background: linear-gradient(to right, #34f351, #ffdde1)" class="gradient"></div>

  <div style="background: linear-gradient(to right, #007991, #78ffd6);" class="gradient"></div>

  ...

</div>
    </body>
</html>